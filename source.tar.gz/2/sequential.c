#include <stdio.h>
#include <stdlib.h>

#define n 4 //number of elements in row,column
#define N 16 //number of elements in square. it must be = rows*columns. N=n*n
#define M 34 // sum of elements in any row, col, diag M = n*(n^2+1)/2

void swap(int *x, int *y){ //swap x for y and y for x
  int t;
  t=*x;  *x=*y;  *y=t;
}

void reverse(int *a,int m){ //reverse first m elements
   int i=0, j=m;
   while(i<j){
     swap(&a[i], &a[j]);
     ++i;  --j;
   }
}

void ant(int *a,int m, int *c){ //antilexicographic permutations
  int i,row,col,sum;  

  if(m==0){//permutation is ready
    *c=*c+1;    
        //check magic in rows
        for (col=0; col<n; col++){
                sum=0;
                for (row=col*n; row<col*n+n; row++){
                sum+=a[row];
                }
                if (sum != M) 
                        break;
        }

        if (sum==M) {
                //check magic in cols
                for (row=0; row<n; row++) {
                        sum=0;
                        for (col=row; col<N; col+=n) {
                                sum+=a[col];
                        }
                        if (sum != M) 
                                break;
                }
                if (sum==M) {
                        //check magic in 1 diag
                        sum=0;
                        for (row=0; row<N; row=row+n+1) {
                                sum+=a[row];
                        }
                        //check magic in 2 diag
                        if (sum==M)     {
                                sum=0;
                                for (i=n-1; i<N-1; i+=n-1) {
                                        sum+=a[i];
                                }
                                if (sum==M){
                                        //print counter
                                        //printf("%d\n",*c);
                                        //print square
                                    for(i=0; i<N; i++){
                                        printf("%d ",a[i]);
                                        if ((i+1)%n==0) printf("\n");
                                    }
                                    //EXIT!
                                    exit(EXIT_SUCCESS);
                                }
                        }
                }
        }
  }else{
    for(i=0; i<=m; i++){
      ant(a,m-1,c);
      if(i<m){
        swap(&a[i], &a[m]);
        reverse(a,m-1);
      }
    }
  }
}

void main()
{
  int i, a[N], c=0;
  // fill array [1,2,3..N]
  for(i=0; i<N; i++)
     a[i] = i+1;
  ant(a,N-1,&c);
}

