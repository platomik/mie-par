#include "mpi.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define n 4 //number of elements in row,column
#define N 16 //number of elements in square. it must be = rows*columns. N=n*n
#define M 34 // sum of elements in any row, col, diag M = n*(n^2+1)/2

/*sequential procedures */
void swap(int *x, int *y){ //swap x for y and y for x
  int t;
  t=*x;  *x=*y;  *y=t;
}

void reverse(int *a,int m){ //reverse first m elements
   int i=0, j=m;
   while(i<j){
     swap(&a[i], &a[j]);
     ++i;  --j;
   }
}

void ant(int *a,int m){ //antilexicographic permutations
  int i,row,col,sum;  
  if(m==0){//permutation is ready

        //check rows
        for (col=0; col<n; col++){
                sum=0; for (row=col*n; row<col*n+n; row++){sum+=a[row];}
                if (sum != M) {
                //	printf ("oops");
                	break;
                }
        }
        if (sum==M) {
                //check columns
                for (row=0; row<n; row++) {
                        sum=0;for (col=row; col<N; col+=n) {sum+=a[col];}
                        if (sum != M) {
//                           	a[0]=999;
                			break;
                        }
                }

        
                if (sum==M) {
                        //check 1st diag
                        sum=0;for (row=0; row<N; row=row+n+1) {sum+=a[row];}
                        //check 2nd diag
                        if (sum==M) {
                        	sum=0; for (i=n-1; i<N-1; i+=n-1) {sum+=a[i];}
						
                                if (sum==M){
                                    MPI_Send (a, N, MPI_INT, 0, 777, MPI_COMM_WORLD);
                                    //exit(EXIT_SUCCESS);
        }      }        }       }


  }else{
    for(i=0; i<=m; i++){
      ant(a,m-1);
      if(i<m){
        swap(&a[i], &a[m]);
        reverse(a,m-1);
      }
    }
  }
}
/* end of sequential procedure*/



int main(int argc, char **argv) {
  int my_rank;
  int p;
  int dest;
  int tag=1;
  int source;
  MPI_Status status;
  int m=100;
  int flag;
  
  int msg, i, j, arr, a[N];
  double t0, t1;

  /* start up MPI */
  MPI_Init( &argc, &argv );

  /* find out process rank */
  MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);

  /* find out number of processes */
  MPI_Comm_size(MPI_COMM_WORLD, &p);

  if (my_rank != 0) {    
  	/* SLAVE */  
	   for (i=1;i<=N;i++)   { //estimate max number of tasks.
	   		//receive task
		    MPI_Recv (a, N, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
		    
			if (status.MPI_TAG==999){break;} /* Receive STOP tag. Stop working.*/
			ant(a,N-2);
			// send to MASTER
			dest=0; 
		    MPI_Send (a, N, MPI_INT, dest, tag, MPI_COMM_WORLD);    
	   }
    
    
  }
  else {
    /* MASTER */
    printf("There are %d tasks.\n", N);    
    printf("There are %d slave processes.\n", p-1);
	t0 = MPI_Wtime(); // start timer
	
    /* send initial data for all processes*/
    for (i=1;i<p;i++) {
      if (i>N) {break;}    	/* if number of processes more than number of tasks*/
      arr=i; /* how many elements already sent*/
      printf ("process %d ",i);
      printf ("get task to make permutation for a[1..N]=[");
		
		/*moving array clockwise*/	
	      for(j=0; j<N; j++) {
	           a[j] = (i+j)%N+1;
	           if (j==N-1){printf ("%d",a[j]);}else{printf ("%d, ",a[j]);}
	      }
      printf ("]\n");

	  // send task to slave
      MPI_Send(a, N, MPI_INT, i, tag, MPI_COMM_WORLD);
    }

    
	/* receive initial data end send next portion*/
    for (source=1;source<=N;) {
      /* checking if message has arrived */
      MPI_Iprobe(MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &flag, &status);      
      /* */
      if (flag) {
      	// slave solved task
        MPI_Recv(a, N, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
        t1 = MPI_Wtime();
        
         /* found */
      	if (status.MPI_TAG==777){
			printf ("\t Found after %f seconds from process %d answered ", t1-t0, status.MPI_SOURCE);
      	
			/*print result*/	
		      for(j=0; j<N; j++) { printf ("%d ",a[j]);} 
		      printf ("\n");
		    /* send STOP to all SLAVES*/        	
//       		for (i=1;i<p;i++) {
//	      		MPI_Send(&i, 1, MPI_INT, i, 999, MPI_COMM_WORLD);
//    		}

      	}
      	
    	/* if not the end of tasks */	
        if (arr<N){    
	        arr++; /* increase number tasks already sent*/
		      printf ("process %d ",status.MPI_SOURCE);
		      printf ("get task to make permutation for a[1..N]=[");
				
				/*moving array clockwise*/	
			      for(j=0; j<N; j++) {
			           a[j] = (arr+j)%N+1;
			           if (j==N-1){printf ("%d",a[j]);}else{printf ("%d, ",a[j]);}
			      }
			  printf ("]\n");

			  // send new task to slave
		   	  MPI_Send(a, N, MPI_INT, status.MPI_SOURCE, tag, MPI_COMM_WORLD);		   	  
        }else{
        	/* end of tasks send STOP to all SLAVES*/        	
       		for (i=1;i<p;i++) {
	      		MPI_Send(&i, 1, MPI_INT, i, 999, MPI_COMM_WORLD);
    		}
        }         
        source++;
      }
    }

  }

  /* shut down MPI */
  MPI_Finalize();
  
  return 0;
}




